// Copyright Epic Games, Inc. All Rights Reserved.

#include "ShooterGame.h"
#include "ShooterTeamStart.h"

AShooterTeamStart::AShooterTeamStart(const FObjectInitializer& ObjectInitializer) 
	: Super(ObjectInitializer) 
{

}
