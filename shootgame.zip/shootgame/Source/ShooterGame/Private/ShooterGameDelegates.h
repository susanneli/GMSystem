// Copyright Epic Games, Inc. All Rights Reserved.
#pragma once

/**
 * Called at startup to setup the FGameDelegates this game needs
 */
void InitializeShooterGameDelegates();
